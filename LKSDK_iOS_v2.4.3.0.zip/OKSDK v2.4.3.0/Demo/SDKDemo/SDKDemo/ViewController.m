//
//  ViewController.m
//  SDKDemo
//
//  Created by Madoka on 17/5/4.
//  Copyright © 2017年 Madoka. All rights reserved.
//

#import "ViewController.h"
#import "OKSDK.h"
#import "OKSDKDelegate.h"
@interface ViewController ()<OKSDKDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view setBackgroundColor:[UIColor yellowColor]];
    
    [[OKSDK defaultSDK] OKSDKInitWithParams:@"{\"gameId\":\"174\"}" withDelegate:self];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)loginBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKLoginWithExt:@"0"];
}

- (IBAction)enterGameBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKEnterGameWithParams:@"{\"userName\":\"madoka\",\"serverId\":\"123321\"}"];
}
- (IBAction)logoutBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKLogout];
}
- (IBAction)userCenterBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKUserCenterWithParams:@"0"];
}
- (IBAction)payBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKPayWithAmount:@"6" AndCustomInfo:@"customInfo" AndProductName:@"元宝" AndProductId:@"com.lk.swlfj.apple.p0" AndExt:@""];
}

- (IBAction)bindPhoneBtnClick:(id)sender {
    [[OKSDK defaultSDK] OKSDKBindPhone];
}

- (void)initSuccessWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)initFalied
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)loginSuccessWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
    [[OKSDK defaultSDK] OKSDKEnterGameWithParams:@"{\"userName\":\"madoka\",\"serverId\":\"123321\"}"];
}

- (void)loginFailedWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)loginCancel
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)switchAccountWithResult:(NSString *)result
{
     NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)logoutSuccessWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)paySuccessWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)payFailedWithResult:(NSString *)result
{
    NSLog(@"%s result:%@",__FUNCTION__,result);
}

- (void)payCancel
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)bindPhoneWithUserName:(NSString *)userName
{
    NSLog(@"%s userName:%@",__FUNCTION__,userName);
}
@end
