//
//  main.m
//  SDKDemo
//
//  Created by Madoka on 17/5/4.
//  Copyright © 2017年 Madoka. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
