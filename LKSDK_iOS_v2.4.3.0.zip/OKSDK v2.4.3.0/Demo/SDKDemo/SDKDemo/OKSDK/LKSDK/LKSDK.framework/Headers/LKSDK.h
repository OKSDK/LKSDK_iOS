//
//  LKSDKDelegate.h
//  LKdelegate
//
//  Created by apple on 13-9-10.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LKSDKDelegate.h"

@interface LKSDK : NSObject
@property (nonatomic, assign) BOOL isOnline;
@property (nonatomic, assign) BOOL isDubug;
#pragma mark - LKSDKNEW
/*!
 *  @author liudx, 15-05-20 10:05:30
 *
 *  @brief  LKSDK-初始化方法
 *
 *  @param params 参数-(json):gameId、appId必传，其他参数根据文档传入
 *  @param block  方法回调
 *
 *  @since 1.0
 */
-(void)LKSDKInitWithGameId:(NSString *)gameId withDelegate:(id<LKSDKDelegate>)delegate;


/*!
 *  @author liudx, 15-05-20 10:05:51
 *
 *  @brief  LKSDK-是否可旋转
 *
 *  @param isRotate 参数: 0-不可旋转，1-可旋转
 *
 *  @since 1.0
 */
-(void)LKSDKSetAutoRotation:(BOOL)isRotate;

/*!
 *  @author liudx, 15-05-20 15:05:37
 *
 *  @brief  LKSDK-进入登录页
 *
 *  @param ext   参数-(json):扩展信息,见文档
 *  @param block 方法回调
 *
 *  @since 1.0
 */
-(void)LKSDKLoginWithExt:(NSString *)ext;

/*!
 *  @author liudx, 15-05-20 16:05:28
 *
 *  @brief  LKSDK-进入游戏
 *
 *  @param params 参数-(json):帐号信息,见文档,需保证userName、serverId 正确性
 *
 *  @since 1.0
 */
-(void)LKSDKEnterGameWithParams:(NSString *)params;

/*!
 *  @author liudx, 15-05-20 16:05:40
 *
 *  @brief  LKSDK-账户登出
 *
 *  @since 1.0
 */
-(void)LKSDKLogout;

/*!
 *  @author liudx, 15-05-21 10:05:54
 *
 *  @brief  LKSDK-创建角色
 *
 *  @param params 参数-(json):具体参数见文档
 *
 *  @since 1.0
 */
-(void)LKSDKCreateRoleWithParams:(NSString *)params;

/*!
 *  @author liudx, 15-05-21 11:05:39
 *
 *  @brief  LKSDK-进入用户中心
 *
 *  @param params 参数-(json):该参数目前没有意义，可以传""
 *
 *  @since 1.0
 */
-(void)LKSDKUserCenterWithParams:(NSString *)params;

/*!
 *  @author liudx, 15-05-21 11:05:26
 *
 *  @brief  LKSDK-进入论坛
 *
 *  @param params 参数-(json):该参数目前没有意义，可以传""
 *
 *  @since 1.0
 */
-(void)LKSDKEnterBBSWithParams:(NSString *)params;
/*!
 *  @author Liudx
 *
 *  @brief  LKSDK-游戏反馈
 *
 *  @param params 传入参数
 */
-(void)LKSDKGameUserFeedback:(NSString *)params;

/*!
 *  @author liudx, 15-05-21 11:05:32
 *
 *  @brief  LKSDK-退出平台
 *
 *  @param block block回调
 *
 *  @since 1.0
 */
-(void)LKSDKExit:(NSString *)params;

/*!
 *  @author Liudx
 *
 *  @brief  LKSDK-检测帐号是否绑定手机
 *
 *  @param block 回调函数
 */
//-(void)LKSDKUserCheckIsBindPhoneWithFinishCallBack:(void (^)(BOOL,NSString *))block;
- (void)LKSDKUpdateLevel:(NSString *)params;

#pragma mark - LKSDKNEW
+(LKSDK*)defaultSDK;

/**
 *  Description
 *  @brief 玩家反馈
 *  @param customInfo 玩家反馈信息json串 用户自定义
 */
-(void)LKGameUserFeedback:(NSString *)customInfo;

#pragma mark 显示暂停页

/**
 *  Description
 *  @brief 暂停游戏
 *  @param customInfo 暂停游戏信息json串 用户自定义
 
 */

- (void)LKGamePause:(NSString *)customInfo;
/**
 *  是否是游客账号
 */
- (BOOL)LKIsFormalUser;
/**
 *  是否已经实名制
 */
- (BOOL)LKHasCertification;
/**
 *  弹出实名账号框
 */
- (void)runCertificationView;
/**
 *  绑定账号
 */
- (void)LKBindAccount;
/**
 *  绑定手机
 */
- (void)LKBindPhone;
/*!
 *  @author Liudx
 *
 *  @brief  获取初始化结果
 *
 *  @return 返回json
 */
- (id)getInitresultWithResult:(NSString *)result;

/**
 *  蓝港激活统计
 */
- (void)lkDeviceActivation;
@end
