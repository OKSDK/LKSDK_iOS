//
//  OKSDKDelegate.h
//  LKdelegate
//
//  Created by apple on 13-9-10.
//  Copyright (c) 2013年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OKSDKDelegate.h"
// SDKVersion:2.4.0.0

@interface OKSDK : NSObject
#pragma mark - SDK接口

/**
 *  单例
 *
 *  @return OKSDK单例对象
 */
+(OKSDK*)defaultSDK;

/**
 *  初始化
 *
 *  @param gameId   游戏id
 *  @param delegate 接收回调的代理对象
 */
-(void)OKSDKInitWithParams:(NSString *)params withDelegate:(id<OKSDKDelegate>)delegate;

/**
 *  登录
 *
 *  @param ext iOS暂无需关注，可传空
 */
-(void)OKSDKLoginWithExt:(NSString *)ext;

/**
 *  账号登出
 */
-(void)OKSDKLogout;

/**
 *  创建角色
 *
 *  @param params 参数-(json):具体参数见文档
 */
-(void)OKSDKCreateRoleWithParams:(NSString *)params;

/**
 *  进入游戏
 *
 *  @param params 参数-(json):帐号信息,见文档,需保证userName、serverId 正确性
 */
-(void)OKSDKEnterGameWithParams:(NSString *)params;
/**
 *  角色升级
 *
 *  @param params 参数-(json):具体参数见文档
 */
-(void)OKSDKUpdateLevelWithParams:(NSString *)params;

/**
 *  充值
 *
 *  @param amount      金额
 *  @param customInfo  自定义透传字段
 *  @param productName 商品名称
 *  @param productId   商品id
 *  @param ext         扩展字段
 */
-(void)OKSDKPayWithAmount:(NSString *)amount
            AndCustomInfo:(NSString *)customInfo
           AndProductName:(NSString *)productName
             AndProductId:(NSString *)productId
                   AndExt:(NSString *)ext;

/**
 *  用户中心
 *
 *  @param params 参数-(json):具体参数见文档
 */
-(void)OKSDKUserCenterWithParams:(NSString *)params;

/**
 *  打开BBS
 *
 *  @param params 参数-(json):该参数目前没有意义，可以传""
 */
-(void)OKSDKEnterBBSWithParams:(NSString *)params;

/**
 *  退出平台
 *
 */
-(void)OKSDKExit;

/**
 *  绑定手机 (蜀山战纪活动特殊接口)
 */
-(void)OKSDKBindPhone;

#pragma mark- 系统方法
/*!
 *  接口预留系统方法
 *  在程序的启动的Appdelegate相应的代理方法里面调用
 */
/**
 *  程序加载完成
 *
 *  @param application
 *  @param launchOptions
 *
 *  @return
 */
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions;
/**
 *  程序获得焦点
 *
 *  @param application
 */
- (void)applicationDidBecomeActive:(UIApplication *)application;
/**
 *  程序进入后台
 *
 *  @param application
 */
- (void)applicationDidEnterBackground:(UIApplication *)application;
/**
 *  程序跳转
 *
 *  @param application
 *  @param url
 *  @param sourceApplication
 *  @param annotation
 *
 *  @return
 */
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation;
/**
 *  程序销毁
 *
 *  @param application
 */
- (void)applicationWillTerminate:(UIApplication *)application;

@end
