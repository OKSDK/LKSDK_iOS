//
//  OKSDKDelegate.h
//  LKPlatformSDK
//
//  Created by 刘东鑫 on 15/7/6.
//  Copyright (c) 2015年 LineKong. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol OKSDKDelegate <NSObject>
@required
/*!
 *  @author Liudx
 *
 *  @brief  初始化成功回调
 *
 *  @param result 初始化成功回调结果
 */
-(void)initSuccessWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  初始化失败回调
 *
 *  @param result 失败回调消息
 */
-(void)initFalied;

/*!
 *  @author Liudx
 *
 *  @brief  登录成功回调
 *
 *  @param result 登录成功回调消息
 */
-(void)loginSuccessWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  登录失败回调
 *
 *  @param result 登录失败回调消息
 */
-(void)loginFailedWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  登录取消回调
 *
 *  @param result 登录取消回调信息
 */
-(void)loginCancel;
/*!
 *  @author Liudx
 *
 *  @brief  登出成功回调
 *
 *  @param result 登出成功回调消息
 */
-(void)logoutSuccessWithResult:(NSString *)result;
/*!
 *  @author Liudx
 *
 *  @brief  切换账号回调
 *
 *  @param result 切换账号回调消息
 */
-(void)switchAccountWithResult:(NSString *)result;

/*!
 *  @author Liudx
 *
 *  @brief  支付成功回调
 *
 *  @param result 支付成功回调消息
 */
-(void)paySuccessWithResult:(NSString *)result;

/*!
 *  @author Liudx
 *
 *  @brief  支付失败回调
 *
 *  @param result 支付失败回调消息
 */
-(void)payFailedWithResult:(NSString *)result;

/*!
 *  @author Liudx
 *
 *  @brief  支付取消
 *
 *  @param result 支付取消回调
 */
-(void)payCancel;

/*!
 *  @author Liudx
 *
 *  @brief  绑定手机回调
 *
 *  @param userName 绑定的用户名
 */
-(void)bindPhoneWithUserName:(NSString *)userName;
@end

